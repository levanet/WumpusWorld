package org.example;

import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;
import jade.wrapper.StaleProxyException;
import org.example.agents.NavigatorAgent;
import org.example.agents.WorldAgent;

public class The_Witcher {
    public static void main(String[] args) {
        jade.core.Runtime rt = jade.core.Runtime.instance();
        Profile p = new ProfileImpl();
        AgentContainer ac = rt.createMainContainer(p);

        try {
            AgentController worldAgentController = ac.createNewAgent("Yennifer", WorldAgent.class.getName(), null);
            worldAgentController.start();


            AgentController navigatorAgentController = ac.createNewAgent("Lutik", NavigatorAgent.class.getName(), null);
            navigatorAgentController.start();

        } catch (StaleProxyException e) {
            e.printStackTrace();
        }
    }
}
